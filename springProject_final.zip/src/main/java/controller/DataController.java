package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import model.domain.Board;
import model.domain.Users;
import repositories.BoardRep;
import repositories.SBoardRep;
import repositories.UserRep;

@RestController
public class DataController {
	
	@Autowired
	private UserRep userRep;
	@Autowired
	private BoardRep boardRep;
	@Autowired
	private SBoardRep sBoardRep;

	
	// 테스트 메소드
	@RequestMapping("test")
	public String test() {
		System.out.println("연결 테스트");
		return "연결 성공!";
	}
	
	// static 폴더의 html 페이지로 넘어가기
	@RequestMapping("modelTest")
	public ModelAndView test2() {
		System.out.println("Model 테스트");
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("test", "succes");
		mv.setViewName("redirect:index.html");
		return mv;
		// 위 4줄와 동일한 코드
		//return new ModelAndView("redirect:index.html", "test", "succes");
	}

	
	
	
	@GetMapping("checkId")
	public Boolean userFind(@RequestParam String id) {
		return userRep.existsById(id);
	}
	
	public Iterable<Users> userFindAll() {
		return userRep.findAll();
	}
	
}

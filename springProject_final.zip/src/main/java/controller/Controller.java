package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import model.domain.Board;
import model.domain.ScreenBoard;
import model.domain.Users;
import repositories.BoardRep;
import repositories.SBoardRep;
import repositories.UserRep;

@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	private UserRep userRep;
	@Autowired
	private BoardRep boardRep;
	@Autowired
	private SBoardRep sBoardRep;
	
	// Controller -> RestController
	@GetMapping("m1")
	public String m1(HttpSession session) {
		return "redirect:/index.html";
	}
	@GetMapping("m2")
	public ModelAndView m2(HttpSession session) {
		String s = userRep.findById("ttt").get().getId();
		ModelAndView mv = new ModelAndView();
		mv.addObject("id", s);
		mv.setViewName("redirect:index.html");
		return mv;
	}
	
	// 회원 가입
	@GetMapping("singup")
	public String singup() {
		return "singUp";
	}
	@PostMapping("userInsert")
	public ModelAndView userInsert(@RequestParam String id, @RequestParam String pwd) {
		Users user = new Users().builder()
				.id(id)
				.pwd(pwd)
				.count(0)
				.rank(1)
				.build();
		userRep.save(user);
		return new ModelAndView("redirect:index","com", "signup");
	}
	
	// 로그인
	@GetMapping("singin")
	public String singin() {
		return "singIn";
	}
	@PostMapping("login")
	public ModelAndView loginCheck(@RequestParam String id, @RequestParam String pwd, HttpSession session) {
		ModelAndView mv = new ModelAndView("singIn");
		if(userRep.existsById(id) && userRep.findById(id).get().getPwd().equals(pwd) ) {
			session.setAttribute("id", id);
			session.setAttribute("rank",userRep.findById(id).get().getRank());
			System.out.println(session.getAttribute("rank"));
			//session.setMaxInactiveInterval(60*10);
			mv.setViewName("redirect:index");
		} else {
			mv.addObject("com", "fail");
		}
		return mv;
	}
	
	// 로그 아웃
	@GetMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:index";
	}
	
	// 글 작성 페이지
	@GetMapping("write")
	public String write() {
		return "writePage";
	}
	
	@GetMapping("writeScreen")
	public String writeScreen() {
		return "screenWrite";
	}
	
	// 미리보기
	@PostMapping("sample")
	public ModelAndView sample(@RequestParam String title, @RequestParam String content) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("title", title);
		mv.addObject("content", content);
		mv.setViewName("viewPage");
		return mv;
	}
	
	// 스크린샷 미리보기
	@PostMapping("sample2")
	public ModelAndView sample2(@RequestParam String title, @RequestParam String content, @RequestParam String photo) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("title", title);
		mv.addObject("content", content);
		mv.addObject("photo", photo);
		mv.setViewName("viewScreenPage");
		return mv;
	}
	
	// 글 저장 
	@PostMapping("saveBoard")
	public ModelAndView saveBoard(@RequestParam String title, @RequestParam String content, HttpSession session) {
		String id = (String) session.getAttribute("id");
		Users user = userRep.findById(id).get();
		Board b = new Board().builder()
				.title(title)
				.contents(content)
				.writer(id)
				.user(user)
				.views(0L)
				.build();
		boardRep.save(b);
		user.getBoards().add(b);
		
		return new ModelAndView("viewBoard", "board", b);
	}
	
	@PostMapping("saveScreenBoard")
	public ModelAndView saveScreenBoard(@RequestParam String title, @RequestParam String content, @RequestParam String photo, HttpSession session) {
		String id = (String) session.getAttribute("id");
		Users user = userRep.findById(id).get();
		ScreenBoard sb = new ScreenBoard().builder()
				.title(title)
				.contents(content)
				.writer(id)
				.user(user)
				.views(0L)
				.img(photo)
				.build();
		sBoardRep.save(sb);
		user.getScreenBoards().add(sb);
		
		return new ModelAndView("viewScreenBoard", "sboards", sb);
	}
	
	@GetMapping("screen")
	public ModelAndView screenshot() {
		return new ModelAndView("screenshot", "sboards", sBoardRep.findAll());
	}
	
	
	// 글 자세히 보기
	@GetMapping("view/{num}")
	public ModelAndView viewPage(@PathVariable Long num) {
		Board board = boardRep.findById(num).get();
		board.setViews(board.getViews()+1);
		boardRep.save(board);
		return new ModelAndView("viewBoard", "board", board );
	}
	// 스크린샷 자세히 보기
	@GetMapping("view2/{num}")
	public ModelAndView view2Page(@PathVariable Long num) {
		ScreenBoard sboard = sBoardRep.findById(num).get();
		sboard.setViews(sboard.getViews()+1);
		sBoardRep.save(sboard);
		return new ModelAndView("viewScreenBoard", "sboards", sboard );
	}
	
	// 글 목록 페이지
	@GetMapping("boardList")
	public ModelAndView boardList() {
		return new ModelAndView("boardList", "boards", boardRep.findAll());
	}
	
	// 인기글 목록 출력
	public List<Board> boardRank(){
		List<Board> li = new ArrayList<>();
		Iterable<Board> it = boardRep.findAll();
		for(Board b : it) {
			li.add(b);
		}
		li.sort((a,b) -> -Long.compare(a.getViews(),b.getViews()));
		
		return li;
	}
	public List<ScreenBoard> sboardRank(){
		List<ScreenBoard> li = new ArrayList<>();
		Iterable<ScreenBoard> it = sBoardRep.findAll();
		for(ScreenBoard b : it) {
			li.add(b);
		}
		li.sort((a,b) -> -Long.compare(a.getViews(),b.getViews()));
		
		return li;
	}
	
	@GetMapping("myWrite")
	public ModelAndView myboard(HttpSession session){
		Users user = userRep.findById((String)session.getAttribute("id")).get();
		ModelAndView mv = new ModelAndView();
		mv.addObject("boards", user.getBoards());
		mv.setViewName("boardList2");
		return mv;
	}
	
	
	@GetMapping("index")
	public ModelAndView main2() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("boards", boardRank());
		mv.addObject("sboards", sboardRank());
		mv.setViewName("index");
		return mv;
	}
	
	// 에러 처리
	@ExceptionHandler
	public ModelAndView handling(Exception e) {
		System.out.println("에러 페이지");
		return new ModelAndView("errorPage");
	}
}

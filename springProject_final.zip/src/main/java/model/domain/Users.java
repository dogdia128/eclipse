package model.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Users {

	@Id
	private String id;
	private String pwd;
	private int count;
	private int rank;
	
	@JsonManagedReference
	@OneToMany(mappedBy="user")
	List<Board> boards = new ArrayList<Board>();
	
	@JsonManagedReference
	@OneToMany(mappedBy="user")
	List<ScreenBoard> screenBoards = new ArrayList<ScreenBoard>();

}

package model.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Board {
	@Id
	@GeneratedValue(generator = "board_seq")
	@SequenceGenerator(name = "board_seq", 
	                  sequenceName = "BOARD_SEQ", 
	                  allocationSize = 1)
	private Long num;
	private String title;
	@Column(length=1000)
	private String contents;
	
	private String writer;
	@JsonBackReference
	@ManyToOne
	@JoinColumn
	private Users user;
	
	private long views;
	
}

package repositories;

import org.springframework.data.repository.CrudRepository;

import model.domain.Board;

public interface BoardRep extends CrudRepository<Board, Long> {

}

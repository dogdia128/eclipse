package repositories;

import org.springframework.data.repository.CrudRepository;

import model.domain.Board;
import model.domain.ScreenBoard;

public interface SBoardRep extends CrudRepository<ScreenBoard, Long> {

}

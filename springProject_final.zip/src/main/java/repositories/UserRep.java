package repositories;

import org.springframework.data.repository.CrudRepository;

import model.domain.Board;
import model.domain.Users;

public interface UserRep extends CrudRepository<Users, String> {

}
